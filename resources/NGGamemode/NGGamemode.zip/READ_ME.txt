The Nerd Gaming game-mode is too large to upload to the MutliTheftAuto Community website, and it's a bundle of resources,
not just a sing resource. To download all the files, please goto http://forum.mtasa.com/viewtopic.php?f=108&t=82870 and
read the post.